package com.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.MedicineDao;
import com.dao.StudentDao;
import com.daoImpl.MedicineDaoImpl;
import com.daoImpl.StudentDaoImpl;
import com.model.Student;

/**
 * Servlet implementation class MedicineController
 */
@WebServlet("/MedicineController")
public class MedicineController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private MedicineDao dao;
	
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	 public MedicineController() {
	        // TODO Auto-generated constructor stub
	        dao = new MedicineDaoImpl();
	    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String action = request.getParameter( "action" );
		if(action.equals("add")) {
			String name = request.getParameter( "name" );
			String qty = request.getParameter( "qty" );
			
			dao.addMedicine(name,qty);
			
			RequestDispatcher view = request.getRequestDispatcher("/success.jsp");
			view.forward(request, response);
			
		}else if(action.equals("list")) {
			request.setAttribute("medicine", dao.getAllMedicine() );
			RequestDispatcher view = request.getRequestDispatcher("/listMedicine.jsp");
			view.forward(request, response);
			
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
	}

}
