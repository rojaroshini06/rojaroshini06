package com.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.dao.MedicineDao;
import com.dao.StudentDao;
import com.example.util.Util;
import com.model.Medicine;
import com.model.Student;

public class MedicineDaoImpl implements MedicineDao {
	
	private Connection conn;

	public MedicineDaoImpl() {
		conn = Util.getConnection();
	}
	
	@Override
	public List<Medicine> getAllMedicine(){
		List<Medicine> medicineData = new ArrayList<Medicine>();
		try {
			Statement statement = conn.createStatement();
			ResultSet resultSet = statement.executeQuery( "select * from medicine" );
			while( resultSet.next() ) {
				Medicine medicine = new Medicine();
				medicine.setName( resultSet.getString( "name" ) );
				medicine.setQty( resultSet.getString( "qty" ) );
				medicineData.add(medicine);
			}
			resultSet.close();
			statement.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return medicineData;
	}

	@Override
	public void addMedicine(String name, String qty) {
		System.out.println("hello");
		try {
			 PreparedStatement preparedStatement = conn.prepareStatement("insert into medicine(name,qty) values (?, ?)");
	            // Parameters start with 1
	            preparedStatement.setString(1, name);
	            preparedStatement.setString(2, qty);
	            preparedStatement.executeQuery();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

}
