package com.dao;

import java.util.List;

import com.model.Medicine;
import com.model.Student;


public interface MedicineDao {

	List<Medicine> getAllMedicine();
	
	void addMedicine(String name, String qty);
	
	
}
